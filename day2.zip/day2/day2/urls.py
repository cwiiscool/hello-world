"""day2 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from app01.new_views import views, supplier_views, shop_views, spider_views, alipay_views, message_views

urlpatterns = [
    url(r'^admin/', admin.site.urls),

    url(r'user_info/$', views.get_user.as_view()),
    url(r'login/$', views.Login.as_view()),
    url(r'register/$', views.Register.as_view()),

    url(r'car_info/$', views.car_info.as_view()),
    url(r'car_info/(?P<pk>\d+)', views.get_car.as_view()),

    url(r'car_category/$', views.car_category.as_view()),

    # 购物车的增删查
    url(r'shop/$', shop_views.ShoppingView.as_view()),

    url(r'show_car/$', shop_views.show_car.as_view()),
    url(r'clear_car/$', shop_views.clear_car.as_view()),
    url(r'clear/$', shop_views.clear_by_car_id.as_view()),

    url(r'get_user/$', views.user_info.as_view()),
    url(r'change_info/$', views.change_info.as_view()),

    # 通过搜索来获取汽车
    url(r'type_car/$', views.get_car_by_type.as_view()),


    # 供应商的一些信息
    url(r'suppliers/$', supplier_views.SupplierInfo.as_view()),

    # 获取分页数据
    url(r'paging_info/$', views.Paging.as_view()),

    # 获取爬虫的信息
    url(r'spiders/$', spider_views.Cars.as_view()),
    url(r'search/$', spider_views.Info.as_view()),

    # alipay 的一些信息配置
    url(r'^page1/', alipay_views.page1.as_view()),
    url(r'^page2/', alipay_views.page2),

    # 和获取验证码的一些信息
    url(r'get_phone/$', message_views.message.as_view()),
]
