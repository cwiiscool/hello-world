from django.db import models


class User(models.Model):
    nid = models.AutoField(primary_key=True)  # 主键
    name = models.CharField(max_length=32)  # 姓名
    pwd = models.CharField(max_length=32)  # 密码
    is_admin = models.IntegerField(default=0)  # 是否为管理员
    # picture = models.FileField()
    brief = models.CharField(max_length=128, null=True)  # 用户的简介
    count = models.IntegerField(default=0)

    address = models.CharField(null=True, max_length=128)
    phone = models.CharField(null=True, max_length=11)
    email = models.EmailField(null=True)

    class Meta:
        verbose_name = "用户"
        verbose_name_plural = verbose_name


class Car(models.Model):
    nid = models.AutoField(primary_key=True)  # 主键
    supplier = models.ForeignKey(to='Supplier')  # 作为供应商的外键
    detail = models.OneToOneField(to='CarDetail',unique=True, to_field='nid',on_delete=models.CASCADE)  # 与汽车详情为一对一关系

    class Meta:
        verbose_name = '汽车'
        verbose_name_plural = verbose_name


class CarDetail(models.Model):
    nid = models.AutoField(primary_key=True)
    category = models.IntegerField(null=True)  # 汽车的分类
    type = models.CharField(max_length=32)  # 汽车品牌
    name = models.CharField(max_length=32)  # 汽车名字
    brief = models.CharField(max_length=128)  # 汽车简介
    price = models.IntegerField()  # 价格
    paging = models.IntegerField(default=1)  # 分页，  属于哪一页的
    count = models.IntegerField(default=5)  # 汽车的库存
    picture = models.CharField(max_length=32)  # 汽车图片

    class Meta:
        verbose_name = '汽车详情'
        verbose_name_plural = verbose_name


class ShoppingCar(models.Model):
    nid = models.AutoField(primary_key=True)
    car_detail = models.ManyToManyField(to='Car')  # 购物车和汽车为多对多关系
    user = models.ForeignKey(to='User',to_field='nid', on_delete=models.CASCADE)  # 与用户为一对多关系


class Supplier(models.Model):
    nid = models.AutoField(primary_key=True)
    supplier_detail = models.OneToOneField(to='SupplierDetail',to_field='nid',unique=True, on_delete=models.CASCADE)  # 供应商与其详情一对一

    class Meta:
        verbose_name = '供应商'
        verbose_name_plural = verbose_name


class SupplierDetail(models.Model):
    nid = models.AutoField(primary_key=True)
    name = models.CharField(max_length=32)
    address = models.CharField(max_length=32)
    brief = models.CharField(max_length=128)
    picture = models.CharField(max_length=32, null=True)
    link = models.CharField(max_length=128, null=True)

    class Meta:
        verbose_name = '供应商详情'
        verbose_name_plural = verbose_name


class Token(models.Model):
    key = models.CharField(max_length=64)
    user = models.OneToOneField(User,related_name='auth_token', on_delete=models.CASCADE)

    created = models.DateTimeField(verbose_name='创建时间', auto_now_add=True)

    def __str__(self):
        return self.key


class Spider(models.Model):
    img = models.CharField(max_length=128)
    brief = models.CharField(max_length=256)
    title = models.CharField(max_length=64)

