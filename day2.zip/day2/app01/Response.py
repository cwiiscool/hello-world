

def Response_dic():
    return {'status': 200, 'msg': 'ok'}
