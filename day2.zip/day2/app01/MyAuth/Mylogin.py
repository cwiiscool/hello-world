

from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed
from app01 import models


class LoginAuth(BaseAuthentication):
    def authenticate(self, request):
        token = request.GET.get('token')
        # // b23a4bf1-0d61-4b89-81d0-a0c279173af1
        ret = models.Token.objects.filter(key=token).first()
        if ret:
            return ret.user, token
        else:
            raise AuthenticationFailed('您该没有登录，请先登录')


class Myexcepthins(Exception):
    def __init__(self, msg):
        self.msg = msg

