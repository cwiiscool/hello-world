from rest_framework.views import APIView
from app01.Response import Response_dic
from rest_framework.response import Response
from app01.spider import get_car_info


class Cars(APIView):
    def get(self, request):
        page = int(request.GET.get('page'))
        print(page)
        response = Response_dic()
        infos = get_car_info.Infos(page)
        response['data'] = infos
        return Response(response)


class Info(APIView):
    def post(self, request):
        response = Response_dic()
        data = request.data.get('data')
        serarch_msg = get_car_info.search(data)
        response['data'] = serarch_msg
        return Response(response)

