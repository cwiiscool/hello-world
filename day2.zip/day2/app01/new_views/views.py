
from django.core.exceptions import ObjectDoesNotExist
from rest_framework.views import APIView
from app01.models import *
from rest_framework.response import Response
from app01.Middle import *
from app01.Response import Response_dic
from app01.MyAuth.Mylogin import Myexcepthins, LoginAuth
import json
import uuid
username = ''


class get_user(APIView):
    def get(self, request):
        user_list = User.objects.all()
        user_ser = User_ser(instance=user_list, many=True)
        return Response(user_ser.data)


class user_info(APIView):
    authentication_classes = [LoginAuth]

    def get(self, request):
        response = Response_dic()
        user_id = request.user.nid
        user_list = User.objects.filter(pk=user_id).first()
        userinfo = User_ser(instance=user_list, many=False)
        response['data'] = userinfo.data
        return Response(response)


class Login(APIView):
    def post(self, request):
        global username
        print('登录请求来了')
        response = Response_dic()
        name = request.data.get('name', None)
        pwd = request.data.get('pwd', None)
        try:
            user_list = User.objects.get(name=name,pwd=pwd)
            if user_list:
                token = uuid.uuid4()
                models.Token.objects.update_or_create(user=user_list, defaults={'key':token})
                if user_list.is_admin == 0:
                    response['msg'] = '登录成功，即将跳转到主页'
                if user_list.is_admin == 1:
                    response['msg'] = '欢迎您，管理员'
                response['name'] = name
                response['token'] = token
        except ObjectDoesNotExist as e:
            response['msg'] = '用户名或密码错误'
            response['name'] = ''
            response['token'] = ''
            response['status'] = 105
        except Myexcepthins as e:
            print(str(e))
        return Response(response)


class Register(APIView):
    def post(self, request):
        print('注册的请求来了')
        response =Response_dic()
        data = request.data.get("data")
        code_test= "#code#=354312"
        print(data)
        name = data['name']
        pwd = data['pwd']
        repwd = data['repwd']
        phone = data['phone']
        email = data['email']
        code = data['code']
        if code in code_test:
            print('验证码正确')
            if pwd != repwd:
                response['pwd_error'] = '两次秘密不一致'
                response['data'] = '注册失败'
                response['msg'] = '两次秘密不一致'
                return Response(response)
            if name:
                user = User.objects.filter(name=name)
                if user:
                    response['status'] = 105
                    response['msg'] = '该用户名已存在，请重新注册'
                    return Response(response)
                else:
                    user_save = User.objects.create(name=name, pwd=pwd, phone=phone, email=email)
                    user_save.save()
                    response['status'] = 200
                    response['msg'] = '注册成功'
                    return Response(response)
            else:
                response['msg'] = '请输入基本信息'
                return Response(response)
        else:
            print('验证码不正确')
            response['msg'] = '验证码不正确'
            return Response(response)


class car_info(APIView):
    def get(self, request):
        car_list = Car.objects.all()
        car_ser = Car_ser(instance=car_list, many=True)
        return Response(car_ser.data)


class car_category(APIView):
    def get(self, request):
        response = Response_dic()
        category = int(request.GET.get('car_category', None))
        car_list = models.Car.objects.all()
        if category:
            car_list =car_list.filter(detail__category=category)
        car_ser = Car_ser(instance=car_list, many=True)
        response['data'] = car_ser.data
        return Response(response)


class get_car(APIView):
    def get(self, request, pk):
        car = Car.objects.filter(pk=pk).first()
        car_ser = Car_ser(instance=car, many=False)
        response = Response_dic()
        response['id'] = pk
        response['data'] = car_ser.data['car_detail']
        print(response['data'])
        return Response(response)


class change_info(APIView):
    authentication_classes = [LoginAuth]

    def post(self, request):
        response = Response_dic()
        user_id = request.user.nid
        user_list = models.User.objects.filter(pk=user_id).first()
        cname = request.data.get('cname', None)
        cpwd = request.data.get('cpwd')
        cmoney = request.data.get('cmoney')
        brief = request.data.get('brief')
        address = request.data.get('caddress')
        if cname and cpwd and brief and address:
            user_list.name = cname
            user_list.pwd = cpwd
            if cmoney:
                user_list.count += int(cmoney)
            user_list.address = address
            user_list.brief = brief
            models.User.objects.filter(pk=user_id).update(name=cname,pwd=cpwd, count= user_list.count,
                                                          address=address,brief=brief)
            response['name'] = cname
            response['msg'] = '修改成功'
        else:
            response['name'] = user_list.name
            response['msg'] = '修改失败，谁知道咋的就失败了呢'
        return Response(response)


class Paging(APIView):
    def post(self, request):
        response = Response_dic()
        paging = request.data.get('paging')
        user_list = models.CarDetail.objects.filter(paging=paging)
        user_ser = CarDetail_ser(instance=user_list, many=True)
        print(user_ser.data)
        response['msg'] = 200
        response['data'] = user_ser.data
        return Response(response)


class get_car_by_type(APIView):
    def post(self, request):
        type_name = request.data.get('type')
        response = Response_dic()
        car = CarDetail.objects.filter(type=str(type_name))
        if car.first():
            print('获取的是当前数据库里面的数据')
            car_ser = CarDetail_ser(instance=car, many=True)
            response['data'] = car_ser.data
            print(car_ser.data)
            response['msg'] = '当前为您展示的是%s的页面' %type_name
            return Response(response)
        else:
            print('获取的不是当前数据库里面的数据')
            car_list = CarDetail.objects.all()
            car_ser = CarDetail_ser(instance=car_list, many=True)
            print(car_ser.data)
            response['data'] = car_ser.data
            response['msg'] = '%s汽车我们暂时还没有' %type_name
            return Response(response)

