
from django.core.exceptions import ObjectDoesNotExist
# Create your views here.
from rest_framework.views import APIView
from app01.models import *
from rest_framework.response import Response
from app01.Middle import *
from app01.Response import Response_dic


class SupplierInfo(APIView):

    def get(self, request):
        response = Response_dic()
        suppliers = models.SupplierDetail.objects.all()
        supplier_ser = SupplierDetailSer(instance=suppliers, many=True)
        response['data'] = supplier_ser.data
        return Response(response)

