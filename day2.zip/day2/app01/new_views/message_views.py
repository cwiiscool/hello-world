import json, urllib.request
from urllib.parse import urlencode
from app01.Response import Response_dic
from rest_framework.response import Response
from rest_framework.views import APIView


class message(APIView):
    def get(self, request):
        phone = request.GET.get('phone')
        print(phone)
        response = Response_dic()
        url = "http://v.juhe.cn/sms/send"
        params = {
            "mobile": phone,  # 接受短信的用户手机号码
            "tpl_id": "156491",  # 您申请的短信模板ID，根据实际情况修改
            "tpl_value": "#code#=354312",  # 您设置的模板变量，根据实际情况修改
        }
        params = urlencode(params).encode('utf-8')
        print(params)
        # key = b3ed1ae6a7f4fa5b214b43e23e1966ac
        response['params'] = params
        f = urllib.request.urlopen(url, params)
        content = f.read()
        res = json.loads(content)
        if res:
            print(res)
        else:
            print("请求异常")
        return Response(response)
