from django_redis import get_redis_connection
from django.core.exceptions import ObjectDoesNotExist
# Create your views here.
from rest_framework.views import APIView
from app01.models import *
from rest_framework.response import Response
from app01.Middle import *
from app01.Response import Response_dic
from app01.MyAuth.Mylogin import Myexcepthins
import json
from app01.MyAuth.Mylogin import LoginAuth


class ShoppingView(APIView):
    authentication_classes = [LoginAuth]
    conn = get_redis_connection()

    def post(self, request):
        print('执行了post方法')
        response = Response_dic()
        car_id = request.data.get('car_id')
        print(request.data)
        car_detail = models.CarDetail.objects.filter(pk=car_id)
        car_ser = CarDetail_ser(instance=car_detail, many=True)
        shopping_bytes = self.conn.get('shopping_car_%s' % request.user.nid)
        shopping_dic = json.loads(shopping_bytes) if shopping_bytes else {}
        print('现在redis里面的数据',shopping_dic)
        if str(car_id) in shopping_dic:
            response['msg'] = '该商品已在您购物车里了'
            response['data'] = shopping_dic
            return Response(response)
        else:
            for car_info in car_ser.data:
                shopping_dic[str(car_id)] = car_info
            response['msg'] = '添加成功'
            response['data'] = shopping_dic
            self.conn.set('shopping_car_%s' %request.user.nid, json.dumps(shopping_dic))
        return Response(response)

    def get(self, request):
        print('执行了get方法')
        response = Response_dic()
        shopping_bytes =self.conn.get('shopping_car_%s' % request.user.nid)
        shopping_dic = json.loads(shopping_bytes) if shopping_bytes else {}
        response['data'] = shopping_dic
        return Response(response)

    def delete(self, request):
        print('执行了delete方法')
        car_id = request.data.get('car_id')
        print(car_id, type(car_id))
        response = Response_dic()
        shopping_bytes = self.conn.get('shopping_car_%s' % request.user.nid)
        shopping_dic = json.loads(shopping_bytes) if shopping_bytes else {}
        shopping_dic.pop(str(car_id))

        self.conn.set('shopping_car_%s' %request.user.nid, json.dumps(shopping_dic))
        response['msg'] = '删除成功'
        return Response(response)


class show_car(APIView):
    authentication_classes = [LoginAuth]
    conn = get_redis_connection()

    def get(self, request):

        print('执行了查看购物车的get方法')
        response = Response_dic()
        shopping_bytes = self.conn.get('shopping_car_%s' % request.user.nid)
        shopping_dic = json.loads(shopping_bytes) if shopping_bytes else {}
        response['data'] = shopping_dic
        print(shopping_dic)
        for data in shopping_dic:
            print(shopping_dic[data], type(shopping_dic[data]))
            response['price'] = shopping_dic[data]['price']
        return Response(response)


class clear_car(APIView):
    authentication_classes = [LoginAuth]
    conn = get_redis_connection()

    def get(self, request):
        response = Response_dic()
        print(request.user.nid)
        shopping_bytes = self.conn.get('shopping_car_%s' % request.user.nid)
        shopping_dic = json.loads(shopping_bytes) if shopping_bytes else {}
        response['data'] = shopping_dic
        all_price = 0
        for data in shopping_dic:
            all_price += int(shopping_dic[data]['price'])
        response['price'] = str(all_price)
        user = models.User.objects.get(pk = request.user.nid)
        user_ser = User_ser(instance=user, many=False)
        # print(user_ser.data)

        if user_ser.data['count'] >= int(response['price']):
            count = user_ser.data['count']
            count -= int(response['price'])
            # shopping_bytes = self.conn.get('shopping_car_%s' % request.user.nid)
            # shopping_bytes =  {}
            self.conn.set('shopping_car_%s' % request.user.nid, json.dumps({}))
            # print(count)
            response['msg'] = '清除购物车成功'
            user.count = count
            user.save()
        else:
            response['msg'] = '您的余额不足'

        return Response(response)


class clear_by_car_id(APIView):
    authentication_classes = [LoginAuth]
    conn = get_redis_connection()

    def post(self, request):
        response = Response_dic()
        car_id = request.data.get('car_id')
        shopping_bytes = self.conn.get('shopping_car_%s' % request.user.nid)
        shopping_dic = json.loads(shopping_bytes) if shopping_bytes else {}
        user = models.User.objects.filter(pk=request.user.nid).first()
        count = int(shopping_dic[str(car_id)]['price'])
        if user.count >= count:
            user.count -= count
            shopping_dic.pop(str(car_id))
            self.conn.set('shopping_car_%s' % request.user.nid, json.dumps(shopping_dic))
            response['msg'] = '购买成功'
            user.save()
        else:
            response['msg'] = '您的余额不足'
        return Response(response)
