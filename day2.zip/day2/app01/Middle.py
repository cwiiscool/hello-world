
from rest_framework import serializers
from app01 import models


class CarDetail_ser(serializers.ModelSerializer):
    class Meta:
        model = models.CarDetail
        fields = '__all__'


class User_ser(serializers.ModelSerializer):
    class Meta:
        model = models.User
        fields = '__all__'


class Car_ser(serializers.ModelSerializer):
    class Meta:
        model = models.Car
        fields = '__all__'

    car_detail = serializers.SerializerMethodField()

    def get_car_detail(self, obj):
        type = obj.detail.type
        name = obj.detail.name
        brief = obj.detail.brief
        price = obj.detail.price
        picture = obj.detail.picture
        count = obj.detail.count
        paging = obj.detail.paging
        ret = {}
        ret['type'] = type
        ret['name'] = name
        ret['brief'] = brief
        ret['price'] = price
        ret['picture'] = picture
        ret['count'] = count
        ret['paging'] = paging
        return ret


class SupplierDetailSer(serializers.ModelSerializer):
    class Meta:
        model = models.SupplierDetail
        fields = '__all__'

    # supplier = serializers.SerializerMethodField()
    #
    # def get_supplier(self, obj):
    #     print(obj.supplier_detail, type(obj.supplier_detail))
    #     detail = obj.supplier_detail.all()
    #     return detail
