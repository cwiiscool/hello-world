from django.contrib import admin

# Register your models here.
from app01 import models
admin.site.register(models.User)
admin.site.register(models.Car)
admin.site.register(models.CarDetail)
admin.site.register(models.ShoppingCar)
admin.site.register(models.Supplier)
