from pymongo import MongoClient

table = None
c = None


def connent_server():
    global table,c
    c = MongoClient("mongodb://cwi:123@127.0.0.1:27017")
    table = c['car']['info']
    print(table)


def insert_data(data):
    if not table:
        connent_server()
    table.insert(data)

