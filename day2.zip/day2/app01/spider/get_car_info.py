from pymongo import MongoClient
import re
rekey = ''


def test():
    c = MongoClient("mongodb://cwi:123@127.0.0.1:27017")
    table = c['car']['info']
    li = []
    for i in list(table.find()):
        del i['_id']
        li.append(i)
    print(len(li))


def car_info():
    c = MongoClient("mongodb://cwi:123@127.0.0.1:27017")
    table = c['car']['info']
    li = []
    for i in list(table.find()):
        del i['_id']
        li.append(i)
    return li


def Infos(page):
    print(page)
    global rekey
    print(rekey)
    infos = search(rekey)
    info = infos[10 * (page - 1):10 * page]
    print(info)
    return info


def search(key):
    global rekey
    if key:
        rekey = key
        if key == "所有":
            info = car_info()
            print(info, len(info))
            return info
        else:
            infos = car_info()
            list = []
            pattern = key + '.*'
            for info in infos:
                if re.findall(pattern,info['name']):
                    list.append(info)
            print(list ,len(list))
            return list


if __name__ == '__main__':
#     test()
    search('雷克萨斯')
#     page = 3
#     infos = car_info()
#     info = infos[30*(page-1):30*page]
#     print(info, len(info))

