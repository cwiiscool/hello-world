from selenium.webdriver import Chrome
from selenium.webdriver import ActionChains
# from urllib.parse import urlencode
import time
import MYmongo
drive = Chrome(r'D:\pyth\爬虫\爬取汽车的数据\car\chromedriver.exe')
# for i in range(1,5):
# i = 1
# url = 'https://price.pcauto.com.cn/price/q-ps40-n'+str(i)+'.html'
# drive.get(url)
# id = drive.find_element_by_id('JlistTb')
# all_class = drive.find_elements_by_class_name('list')
# print(all_class)
# for data in all_class:
#     img_path = data.find_element_by_class_name('thlieBiao')
#     img_link = img_path.find_element_by_class_name('pic').find_element_by_css_selector('a img')
#     print(img_link.get_attribute('src'))
for i in range(1,5):
    drive.get('http://product.auto.163.com/search_daquan/price=35-50/#0008B08')
    tag1 = drive.find_element_by_class_name('j-search-hot-content')
    # lis = tag1.find_elements_by_css_selector('li p a img')
    titles = tag1.find_elements_by_css_selector('li')
    for title in titles:
        name = title.find_elements_by_css_selector('p a')[1].text
        money = title.find_element_by_css_selector('div span em').text
        link = title.find_element_by_css_selector('p a img').get_attribute('src')
        dic = {"link":link,"name": name, "money": money}
        MYmongo.insert_data(dic)

    tag = drive.find_element_by_id('hot-page')
    next_page = tag.find_element_by_class_name('nextPage')

    asc = ActionChains(drive)
    asc.click(next_page).perform()

    time.sleep(3)



